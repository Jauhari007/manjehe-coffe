<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  ...$guards
     * @return mixed
     */
    public function handle($request, Closure $next, ...$guards)
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                // Jika admin, redirect ke dashboard admin
                if ($guard === 'admin' || $request->is('admin') || $request->is('admin/*')) {
                    return redirect()->route('admin.dashboard');
                }
                // Default: redirect ke home
                return redirect('/');
            }
        }

        return $next($request);
    }
}
